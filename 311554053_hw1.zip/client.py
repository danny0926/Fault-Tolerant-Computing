import grpc
import argparse
import voting_pb2_grpc
import voting_pb2
import time
import psutil


### user login
def try_login(stub, UserName):
    VoterName = voting_pb2.VoterName(name=UserName)
    ### get a challenge need to response
    
    Challenge = stub.PreAuth(VoterName)
    
    ### package the response and the user name into the Request
    request = voting_pb2.AuthRequest()
    request.name.name = VoterName.name
    request.response.value = Challenge.value

    ### get the response
    #print(f'put request:\n')
    #print(request)
    response = stub.Auth(request)
    #print(f'get response:\n')
    #print(response)
    return response

def find_grpc_connections():
    # 獲取本地網絡接口信息
    netifs = psutil.net_if_addrs()
    # 遍歷每個接口
    for netif in netifs:
        # 遍歷接口上的所有連接
        for conn in psutil.net_connections(kind='tcp'):
            # 判斷該連接是否使用了 gRPC 協議
            if 'grpc' in conn.laddr and conn.status == 'ESTABLISHED':
                # 如果是 gRPC 連接，則建立 gRPC 通道並查詢相關信息
                print(f'gRPC connection found on interface {netif}: local={conn.laddr}, remote={conn.raddr}')
                with grpc.insecure_channel(f"{conn.laddr[0]}:{conn.laddr[1]}") as channel:
                    stub = voting_pb2_grpc.eVotingStub(channel)
                    # response = stub.SayHello(HelloRequest(name='Alice'))
                    # print("Response received: " + response.message)
                    print("find the port using gRPC")
                    
    print('search down, press any key to continue...')
    input()

def parse_arguments():
    parser = argparse.ArgumentParser(description='Client')
    parser.add_argument('--host', default='localhost', type=str)
    parser.add_argument('--port', default='50051', type=str)
    
    return parser.parse_args()

if __name__ == '__main__':
    args = parse_arguments()
    host = args.host
    port = args.port
    
    find_grpc_connections()
    
    ### connect to the localhost:50051
    channel = grpc.insecure_channel(host + ':' + port)
#     with grpc.insecure_channel(host + ':' + port) as channel:
    print(f'listening to {host}:{port}......')
    ### make a stub
    stub = voting_pb2_grpc.eVotingStub(channel)
    
    ### create the username
    UserName = 'Danny'
    
    
    ### try to login and get the response from the server (AuthToken)
#     for _ in range(10):
    try:
        
        response = try_login(stub, UserName)

    except:
        voter = voting_pb2.Voter(name=UserName, group='0', public_key=str.encode('311554053'))
        stub.RegisterVoter(voter)
        response = try_login(stub, UserName)
    
#     time.sleep(1)
    print(response)
    channel.close()
        