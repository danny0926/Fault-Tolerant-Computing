import voting_pb2_grpc
import voting_pb2
import socket
import grpc
import time
import enum
import argparse
import numpy as np
from concurrent import futures


### status to num
class UserStatus(enum.IntEnum):
    NotRegister = 0
    Registered = 1
    

class VoteServerStatus(enum.IntEnum):  ### vote platform open or stop
    Start = 0
    End = 1


class loginStatus(enum.IntEnum):
    Success = 0
    Fail = 1


class VoterStatus(enum.IntEnum):  ### vote success or fail
    Success = 0
    Fail = 1

### class User
class User():
    def __init__(self, name, group, public_key):
        self.name = name
        self.group = group
        self.public_key = public_key
        
        self.challenge = 0
        self.auth_token = 0
        
    def set_challenge(self, challenge):
        self.challenge = challenge
        
    def set_authToken(self, token):
        self.auth_token = token


def find_idx(List, target, using='name'):
    ### only can find the user in User List
    for i in range(len(List)):
        if using == 'name':
            if List[i].name == target:
                return i
        if using == 'token':
            if List[i].auth_token == target:
                return i
            
    return -1


### class candidate
class candidate():
    def __init__(self, name):
        self.name = name
        self.get_vote = 0

### make the server, make sure it need to inherent from voting_pb2_grpc.eVotingServicer
class eVotingServicer(voting_pb2_grpc.eVotingServicer):
    ### implement functionality if the server
    def __init__(self,):
        self.Users = []
        
    
    def RegisterVoter(self, request, context):
        ### register the new user
        
        self.Users.append(User(name=request.name, group=request.group, public_key=request.public_key))
        
        ### after register to the server, need to login the server
        Status = voting_pb2.Status(code=UserStatus.Registered)
        
        if Status.code == UserStatus.Registered:
            print(f'USER {request.name} register successfully.')
        else:
            print(f'USER {request.name} register failed.')
            
        return Status
    
    def UnregisterVoter(self, request, context):
        name = request.name
        
        user_idx = find_idx(Users, name)    # find the index of the user
        self.Users.pop(user_idx)
        
        Status = voting_pb2.Status(code=UserSataus.NotRegister)
        
        return Status
    
    
    def PreAuth(self, request, context):
        name = request.name
        # VoterName request
        
        user_idx = find_idx(self.Users, name)
        
        ### generate 4 bits number randomly as the challenge
        encoded = np.random.bytes(4)
        Challenge = voting_pb2.Challenge(value=encoded)
        
        print(f'Send challenge: {Challenge.value} to user: {name}')
        
        self.Users[user_idx].set_challenge(encoded)
        
        return Challenge
    
    
    def Auth(self, request, context):
        # AuthRequest request
        name = request.name.name
        response = request.response.value
        
        idx = find_idx(self.Users, name)
        judge_challenge = self.Users[idx].challenge
        
        print(f'Got the response from client {name}')
        if judge_challenge == response:
            ### success, user can login the server
            print(f'{name} login the server')
            token = np.random.bytes(4)
            
            ### 0 is used for fail login
            token = 1 if token == 0 else token
            AuthToken = voting_pb2.AuthToken(value=token)
        else:
            ### fail to login
            print(f'{name} fail to login the server')
            token = 0
            AuthToken = voting_pb2.AuthToken(value=token)
        
        self.Users[idx].set_authToken(token)    
        
        return AuthToken
    
    
    def CreateElection(self, request, context):
        ### Election request
        name = request.name
        groups = request.groups
        choices = request.choices
        token = request.token.value
        '''
         assume 
             1. there are three candidates: A, B, C
             2. only one voting group
             3. end_date and token are not used
        '''
        self.voting_name = name
        self.candidates = []
        
        ### 3 candidates
        self.candidates.append(candidate('A'))
        self.candidates.append(candidate('B'))
        self.candidates.append(candidate('C'))
        
        
        
        Status = voting_pb2.Status(code=VoteServerStatus.Start)
        
        return Status
    
    
    def CastVote(self, request, context):
        ### Vote request
        
        election_name = request.elecion_name    ### assume there is only one election, so this term not used
        choice_name = request.choice_name
        using_token = request.token.value
        
        if find_idx(Users, using_token, using='token') != -1:
            idx = find_idx(self.candidates, choice_name)
            
            candidates[idx].get_vote += 1
            Status = voting_pb2.Status(code=VoterStatus.Success)
        
        else:
            Status = voting_pb2.Status(code=VoterStatus.Fail)
    
        return Status
        
        
    def GetResult(self, request, context):
        #### ElectionName request
        
        voting_name = request.name
        
        ### we only has 3 candidates called : A, B, C
        max_votes = -1
        elected = 'None'
        for candidate in self.candidates:
            if candidate.get_vote > max_vote:
                max_vote = candidate.get_vote
                elected = candidate.name
                
        VoteCount = voting_pb2.VoteCount(choice_name=elected, count=max_vote)
        ElectionResult = voting_pb2.ElectionResult(status=VoteServerStatus.End, counts=VoteCount)
        
        return ElectionResult
    
 
def parse_arguments():
    parser = argparse.ArgumentParser(description='Server')
    parser.add_argument('--host', default='[::]', type=str)
    parser.add_argument('--port', default='50051', type=str)
    
    return parser.parse_args()
    
def serve(host, port):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    voting_pb2_grpc.add_eVotingServicer_to_server(eVotingServicer(), server)
    
    ip = socket.gethostbyname(socket.gethostname())
    print(f'Starting server on {ip}:{port}')
    
    # with open('server.key', 'rb') as fp:
    #     server_key = fp.read()
    # with open('server.pem', 'rb') as fp:
    #     server_cert = fp.read()
    # with open('ca.pem', 'rb') as fp:
    #     ca_cert = fp.read()
    # creds = grpc.ssl_server_credentials([(server_key, server_cert)], root_certificates=ca_cert, require_client_auth=True)
    server.add_insecure_port(host + ':' + port)
    print(f'server is acting......')
    server.start()
    
    try:
        while True:
            time.sleep(86400)
            
    except KeyboardInterrupt:
        server.stop(0)
      
      
if __name__ == '__main__':
    args = parse_arguments()
    port = args.port
    host = args.host
    
    serve(host=host, port=port)